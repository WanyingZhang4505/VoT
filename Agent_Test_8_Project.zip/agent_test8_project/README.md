# Agent Test 8 reproducible HIC project

This folder is a self-contained export of the local Agent Test 8 runner, its frozen run, source inputs, initial retrieval snapshot, scoring/audit records, and the later memory-ingestion experiment. It does not include API credentials, Python virtual environments, model-weight caches, or unrelated working-directory scratch files.

## What is included

- `scripts/run_agent_test8.py`: frozen serial A/B runner, still bound to `agent_test_8`. Its model responses are supplied through the Codex task-agent queue; this package does not silently switch it to DeepSeek.
- `scripts/run_agent_test6.py` and HIC modules: the shared prompt, local BGE-M3 embedding, Qdrant, data-loading, and scoring implementation used by Test 8.
- `data/`: all eight source CSVs pinned by the local HIC source manifest, including the three Test 8 validation families.
- `LLM/evaluations/Agent Test 8/`: all original frozen run artifacts, post-hoc follow-up records, and memory-ingestion audit. The original run has 15 cases.
- `agent_test_7_full_points.jsonl`: the byte-hashed 703-point collection export used to initialize the original Test 8 evaluation. The copied collection uses 1024-dimensional Cosine vectors.
- `scripts/restore_agent_test8_snapshot.py`: safe restore of that baseline to a new local `agent_test_8` collection; it refuses to overwrite an existing collection.
- `docker-compose.yml`: isolated loopback-only local Qdrant service on REST 6333 and gRPC 6334.

## Setup

Use Python 3.12 and install `config/requirements.txt`. Download `BAAI/bge-m3` to the local Hugging Face cache before running; model weights are not embedded in this source bundle. Keep any provider credentials in a local ignored environment file and never commit them.

Start Qdrant with `docker compose up -d`, restore the original baseline, then check `python scripts/run_agent_test8.py status`. For the original one-pass benchmark, leave the collection at 703 points. The frozen runner rejects a different point count.

The historical evaluation run uses the Codex task-agent queue. `advance-one` can return an `awaiting_worker` task; the in-app Codex worker must answer it, then `record-task` records the response. The sequence is serialized and each case is scored only after the A/B forecast lock.

## Current 718-point library

The live local collection was extended from 703 to 718 points after the original evaluation by appending 15 validation-derived experiences. To recreate that *post-score* library in a fresh Qdrant instance, restore the 703-point baseline and follow `LLM/evaluations/Agent Test 8/memory_ingest_after_eval_20261101/reports/ingest_report.md` with `scripts/ingest_agent_test8_validation_experiences.py`. This step writes the validation-derived memories and the resulting 718-point collection must not be used to claim a blind evaluation on those same cases. The original frozen run remains unchanged.

## Scope and interpretation

The frozen set contains Health/H36 (3), Security/H10 (3), and new_metr/H192 (9). Target meaning and units remain unknown, so scores use the source numeric targets as-is. The 15 cases are validation cases; outer-test targets were not read by the original run. The five post-hoc correction revisions used validation-error feedback and are not independent blind evidence.

For the exact original predictions, inspect the included forecast locks and raw task responses. Re-running a language model can produce different responses and is not an exact replay.
