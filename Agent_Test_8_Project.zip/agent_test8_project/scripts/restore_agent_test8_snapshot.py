"""Restore the frozen 703-point Agent Test 8 baseline from its JSONL export."""
from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
from qdrant_client import QdrantClient, models

ROOT=Path(__file__).resolve().parents[1]
DEFAULT_SNAPSHOT=ROOT/"LLM/evaluations/Agent Test 8/remaining3families_15_20261101/preflight/qdrant_snapshot/agent_test_7_full_points.jsonl"
COLLECTION="agent_test_8"
URL="http://127.0.0.1:6333"

def main():
 p=argparse.ArgumentParser(description=__doc__); p.add_argument("--snapshot",type=Path,default=DEFAULT_SNAPSHOT); p.add_argument("--url",default=URL); a=p.parse_args()
 path=a.snapshot.resolve(strict=True); digest=hashlib.sha256(path.read_bytes()).hexdigest(); rows=[]
 for line in path.read_text(encoding="utf-8").splitlines():
  row=json.loads(line); vec=row.get("vector")
  if not isinstance(vec,list) or len(vec)!=1024 or any(not math.isfinite(float(v)) for v in vec): raise ValueError("snapshot contains an invalid 1024-D vector")
  rows.append(row)
 if len(rows)!=703: raise ValueError(f"expected 703 baseline points; found {len(rows)}")
 client=QdrantClient(url=a.url,timeout=60)
 try:
  if client.collection_exists(COLLECTION): raise FileExistsError(f"{COLLECTION} already exists; refusing to overwrite")
  client.create_collection(collection_name=COLLECTION,vectors_config=models.VectorParams(size=1024,distance=models.Distance.COSINE))
  for start in range(0,len(rows),64):
   batch=rows[start:start+64]
   client.upsert(collection_name=COLLECTION,wait=True,points=[models.PointStruct(id=r["id"],vector=r["vector"],payload=r["payload"]) for r in batch])
  info=client.get_collection(COLLECTION)
  count=len(client.scroll(collection_name=COLLECTION,limit=1,with_payload=False,with_vectors=False)[0])
  if info.points_count!=703 or str(info.status).lower()!="green": raise RuntimeError(f"restore verification failed: status={info.status}, points={info.points_count}")
  receipt={"source_snapshot":path.name,"sha256":digest,"snapshot_lines":len(rows),"collection":COLLECTION,"points_count":info.points_count,"status":str(info.status),"dimension":1024,"distance":"Cosine","verified_utc":__import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()}
  out=ROOT/"restore_receipt.json"
  with out.open("x",encoding="utf-8") as f: json.dump(receipt,f,indent=2,ensure_ascii=False); f.write("\n")
  print(json.dumps(receipt,indent=2,ensure_ascii=False))
 finally: client.close()
if __name__=="__main__": main()
